#!/bin/bash
echo 'Received SMS... sending via MQTT'
